// Importing Dependencies
import React from 'react';

// Importing Components
// edit component

// Importing Styles
import './EditModal.css';


const EditModal = (props) => {

    return (
        <div className="edit_modal">
           edit
        </div>
    );
} 

export default EditModal;