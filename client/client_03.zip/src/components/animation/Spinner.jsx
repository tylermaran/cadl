import React from 'react';

// Importing styling
import './Spinner.css'


const Spinner = () => {
    return (
        <div className="spinner"></div>
    );
}
  
export default Spinner;